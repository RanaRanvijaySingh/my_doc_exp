
abstract class Person
{
	String name;
	byte age;
	char gender[];
	String profession;
	short height;
	short weight;
	char date_of_birth[];
	
	
}
