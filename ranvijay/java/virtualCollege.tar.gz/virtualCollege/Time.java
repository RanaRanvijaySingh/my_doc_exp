class Time {
    short min,sec,hour;
    
}
