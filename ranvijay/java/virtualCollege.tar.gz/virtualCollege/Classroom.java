
////////////////////////////////////////////////////////
/*CREATIONAL DESIGN PATTERN :  FACTORY PATTERN*/
////////////////////////////////////////////////////////
class Classroom extends Room {
    Classroom()
    {
        /*initialize all the papameters*/
   //     System.out.println("classroom : constructor");

       
    }

    void checkRoutine() {
        // check if the room is available or not ..
     //   System.out.println("classroom : check routine");
 
        
    }
   
}
