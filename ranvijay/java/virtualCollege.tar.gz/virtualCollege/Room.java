abstract class Room 
{
	char room_no[];
	short no_of_chair;
	short no_of_table;
	short capacity_of_room;	
}