////////////////////////////////////////////////////////
/*CREATIONAL DESIGN PATTERN :  FACTORY PATTERN*/
////////////////////////////////////////////////////////
class Lab extends Room {
    Lab()
    {
        /*initialize all the papameters*/
       // System.out.println("lab: constructor");
       
    }
     void checkRoutine() {
        // check if the room is available or not ..
     //   System.out.println("classroom : check routine");
 
        
    }
   
     
}
