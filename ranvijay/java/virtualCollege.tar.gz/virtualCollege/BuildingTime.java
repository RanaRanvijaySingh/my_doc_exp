public interface BuildingTime {


    void setOpenCloseTime();
}
