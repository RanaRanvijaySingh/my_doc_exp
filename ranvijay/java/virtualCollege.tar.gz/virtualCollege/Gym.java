////////////////////////////////////////////////////////
/*CREATIONAL DESIGN PATTERN :  FACTORY PATTERN*/
////////////////////////////////////////////////////////
public class Gym extends Room{
    short no_of_equipments;
    String trainer_name;
    short no_of_machine;
    Gym(){
        /*initialize all companents */
//        System.out.println("Gym  : constructor");
         
    }

    boolean aMember(Student stud) {
        //if the studen is the member of the gym
        return true ;
    }

    void addNewMember(Student stud) {
        
        // add new member to the gym ..
    }
   
}
