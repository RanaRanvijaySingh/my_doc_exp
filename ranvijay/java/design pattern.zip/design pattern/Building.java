abstract class Building {
    
	String build_name;
	String establish_date;
	short hight;
	short length;
	short breath;
	float area;
	short no_of_staff;
        String open_time;
        String close_time;
	abstract public void setOpenCloseTime();
       
}

