////////////////////////////////////////////////////////
/*CREATIONAL DESIGN PATTERN :  FACTORY PATTERN*/
////////////////////////////////////////////////////////

class Staff extends Person {
    String staff_if;
    Staff()
    {
        /*initialize all components */
         //System.out.println("staff : constructor");
       
        
    }
    
}
