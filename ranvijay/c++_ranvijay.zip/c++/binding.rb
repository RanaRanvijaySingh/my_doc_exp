class  yClass  	
____   "  "  	
	def  nitialize(s)  		
________   s  	
	end  	
def  etBinding
		return  inding()
  	end
 nd  
class  yOtherClass  
  @x   "  "
  	def  nitialize(s)
    @mystr   s  	
	end  	

	def  etBinding
		return  inding()
  	end
 nd  

			 
