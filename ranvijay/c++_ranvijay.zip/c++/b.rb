class  yClass  	
____   "  "  	
	def  nitialize(s)  		
________   s  	
	end  	
	def  etBinding
________________ng()
  	end
end  
class  yOtherClass  
________________________________)
  		@mystr   s  	
	end  	

	def  etBinding
________________________________________________________________